from Buscador_De_Patrones import Buscador_De_Patrones
from Operaciones_Matematicas import Operaciones_Matematicas
from Graficador import Graficador
from Manejador_De_Archivos import Manejador_De_Archivos

# Recuperar datos
manejador = Manejador_De_Archivos()
lista_datos = manejador.leerListaDatos()
lista_fechas = manejador.leerListaFechas()

# Se sacan la media y la desviacion
operaciones = Operaciones_Matematicas()

media = operaciones.SacarMedia(lista_datos)
desviacion_media = operaciones.SacarDesviacionMedia(lista_datos, media)

# Se buscan los patrones
buscador = Buscador_De_Patrones()

buscador.AjustarLimites(media, desviacion_media)

for i in range(len(lista_datos)):
    buscador.BuscarPatron5(lista_datos, lista_fechas, i)
    buscador.BuscarPatron6(lista_datos, lista_fechas, i)
    buscador.BuscarPatron7(lista_datos, lista_fechas, i)
    buscador.BuscarPatron8(lista_datos, lista_fechas, i)

# Se grafican los datos
graficador = Graficador()

graficador.AjustarLimites(media, desviacion_media)

graficador.GraficarA(lista_datos, lista_fechas)
graficador.GraficarB(lista_datos, lista_fechas)