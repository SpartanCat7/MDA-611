from datetime import datetime

from Generador_De_Datos import Generador_De_Datos
from Manejador_De_Archivos import Manejador_De_Archivos

# Se definen los parametros
cantidad_de_datos = 500
valor_minimo = 2000
valor_maximo = 4000
fecha_inicio = datetime(2019,8,1,0,0,0)

# Se generan los datos
generador = Generador_De_Datos()

lista_datos = generador.GenerarListaDatos(cantidad_de_datos, valor_minimo, valor_maximo)
lista_fechas = generador.GenerarListaFechas(cantidad_de_datos, fecha_inicio)

# Guardar los datos
manejador = Manejador_De_Archivos()
manejador.generarExcel(lista_fechas, lista_datos)