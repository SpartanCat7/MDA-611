class Manejador_De_Archivos:
    def generarExcel(self, x, y):
        import xlsxwriter
        libro = xlsxwriter.Workbook('Datos.xlsx')
        hoja = libro.add_worksheet()
        fila = 0
        columna = 0
        for dato in x:
            hoja.write(fila,columna,dato)
            fila += 1
        columna = 1
        fila=0
        for dato in y:
            hoja.write(fila,columna,dato)
            fila += 1
        libro.close()

    def leerListaDatos(self):
        import xlrd
        from pathlib import Path
        import os
        wb = xlrd.open_workbook(os.path.join(Path().absolute(), 'Datos.xlsx'))
        sheet = wb.sheet_by_index(0)
        ret = []
        for i in range(sheet.nrows):
            ret.append(sheet.cell_value(i, 1))
        return ret

    def leerListaFechas(self):
        import xlrd
        from pathlib import Path
        import os
        wb = xlrd.open_workbook(os.path.join(Path().absolute(), 'Datos.xlsx'))
        sheet = wb.sheet_by_index(0)
        ret = []
        for i in range(sheet.nrows):
            ret.append(sheet.cell_value(i, 0))
        return ret